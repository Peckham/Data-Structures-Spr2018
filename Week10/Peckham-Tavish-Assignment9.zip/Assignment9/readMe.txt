Tavish Peckham
Professor Dey
TA RuoWen Tan
Data Structures Spring 2018
readMe.txt

1.3
The best-case runtime complexity of insertion sort is O(n) comparisons and O(1)
swaps. This is the case when the list in question is already sorted.

1.4
The worst-case runtime complexity of insertion sort is O(n^2) comparisons and
O(n^2) swaps. This is the case when the list in question is reverse sorted,
in other words when the list is sorted in descending order.

2.3
The best-case runtime complexity of summer sort is O(n) comparisons and O(1)
swaps. This is the case when the list in question is already sorted.

2.4
The worst-case runtime complexity of summer sort is O(n^2) comparisons and
O(n^2) swaps. This is the case when the list in question is reverse sorted,
in other words when the list is sorted in descending order.

3.3
The best-case runtime complexity of comb sort is O(nlogn) comparisons and O(nlogn)
swaps. This is the case when the list in question is already sorted.

3.4
The worst-case runtime complexity of comb sort is O(n^2) comparisons and
O(n^2) swaps. This is the case when the list in question is reverse sorted,
in other words when the list is sorted in descending order.
