class SingleLinkedList:

    class _Node:
        """Lightweight, nonpublic class for storing a singly linked node."""
        __slots__ = '_element', '_next'         # streamline memory usage

        def __init__(self, element, next):      # initialize node's fields
            self._element = element               # reference to user's element
            self._next = next                     # reference to next node

    def __init__(self):
        """Create an empty linkedlist."""
        self._head = None
        self._size = 0

    def __len__(self):
        """Return the number of elements in the linkedlist."""
        return self._size

    def is_empty(self):
        """Return True if the linkedlist is empty."""
        return self._size == 0

    def top(self):
        """Return (but do not remove) the element at the top of the linkedlist.

        Raise Empty exception if the linkedlist is empty.
        """
        if self.is_empty():
            pass  # raise Empty('list is empty')
        return self._head._element              # head of list

    def insert_from_head(self, e):
        """Add element e to the head of the linkedlist."""
        # Create a new link node and link it
        new_node = self._Node(e, self._head)
        self._head = new_node
        self._size += 1

    def delete_from_head(self):
        """Remove and return the element from the head of the linkedlist.

        Raise Empty exception if the linkedlist is empty.
        """
        if self.is_empty():
            pass  # raise Empty('list is empty')
        to_return = self._head._element
        self._head = self._head._next
        self._size -= 1
        return to_return

    def __str__(self):
        result = []
        result.append("head --> ")
        curNode = self._head
        while (curNode is not None):
            result.append(str(curNode._element) + " --> ")
            curNode = curNode._next
        result.append("None")
        return "".join(result)

    def sameSame(self, otherlist):
        if self._size != otherlist._size:
            return False
        curNode = self._head
        otherNode = otherlist._head
        while curNode._next is not None:
            if curNode._element != otherNode._element:
                return False
            curNode = curNode._next
            otherNode = otherNode._next
        return True

    def remove_all_occurance(self, value):
        # remove all occurance of value in linked list. return nothing.
        # Example:
        # head --> 5 --> 4 --> 2 --> 4 --> 1 --> 9 --> 4 --> None
        # >>> l.remove_all_occurance(4)
        # head --> 5 --> 2 --> 1 --> 9 --> None
        # @parameter1: value, the value we are trying to remove from the self
        # list. @return: Nothing
        curNode = self._head
        while curNode._element == value:
            self.delete_from_head()
            curNode = curNode._next
            if curNode is None:
                return
        while curNode._next is not None:
            while curNode._next._element == value:
                curNode._next = curNode._next._next
            curNode = curNode._next
        return

    def reverse(self):
        # reverses self list.
        # Example:
        # head --> 1 --> 2 --> 3 --> 4 --> None
        # >>> l.reverse()
        # head --> 4 --> 3 --> 2 --> 1 --> None
        # @return: Nothing
        elements = []
        curNode = self._head
        while curNode is not None:
            elements.append(curNode._element)
            curNode = curNode._next
        l3 = SingleLinkedList()
        for i in elements:
            l3.insert_from_head(i)
        self._head = l3._head


# Flip those booleans to enable test cases
sameSameTest = False
remove_all_occuranceTest = False
reverseTest = True


if (sameSameTest):
    print("-----------Testing sameSame-------------")
    l1 = SingleLinkedList()
    l2 = SingleLinkedList()
    for i in range(5):
        l1.insert_from_head(i)
        l2.insert_from_head(i)
    print("Is l1 sameSame l2? Your answer:", l1.sameSame(l2))   # True

if (remove_all_occuranceTest):
    print("-----------Testing remove_all_occurance-------------")
    l1 = SingleLinkedList()
    for i in range(10):
        l1.insert_from_head(5)
        l1.insert_from_head(6)
        l1.insert_from_head(6)
        l1.insert_from_head(2)

    print(l1, "\n")
    l1.remove_all_occurance(6)
    print(l1)  # None

if (reverseTest):
    print("-----------Testing reverse-------------")
    l1 = SingleLinkedList()
    for i in range(10):
        l1.insert_from_head(i)
    print(l1)  # 9-->8-->7-->6-->5-->4-->3-->2-->1-->0-->None
    l1.reverse()
    print(l1)  # 0-->1-->2-->3-->4-->5-->6-->7-->8-->9-->None
